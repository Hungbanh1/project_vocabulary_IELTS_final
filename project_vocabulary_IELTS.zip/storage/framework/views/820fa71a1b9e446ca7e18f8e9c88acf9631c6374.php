    
    <?php $__env->startSection('content'); ?>
        <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@2.8.2/dist/alpine.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        
        <?php if(session('success')): ?>
            <script>
                Swal.fire({
                    title: "Thành công!",
                    text: "<?php echo e(session('success')); ?>",
                    icon: "success",
                    confirmButtonText: "OK"
                });
            </script>
        <?php endif; ?>

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <?php
                $defaultUrl = url('/');
                $type_of_voca = request()->segment(1); // adj , adv ,...
                $fullUrl = request()->fullUrl();
            ?>
            
            <div class="container ">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Vocabulary</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav no-marker">
                        <li class="nav-item">
                            <a class="nav-link <?php echo e($type_of_voca == 'adv' ? 'active' : ''); ?>"
                                href="<?php echo e(route('adv')); ?>">Trạng
                                từ</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e($type_of_voca == 'adj' ? 'active' : ''); ?>" href="<?php echo e(route('adj')); ?>">Tính
                                từ</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e($type_of_voca == 'N' ? 'active' : ''); ?>" href="<?php echo e(route('N')); ?>">Danh
                                từ</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e($type_of_voca == 'V' ? 'active' : ''); ?>" href="<?php echo e(route('V')); ?>">Động
                                từ</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e($type_of_voca == 'Phrase' ? 'active' : ''); ?>"
                                href="<?php echo e(route('Phrase')); ?>">Cụm từ</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e($type_of_voca == 'edit' ? 'active' : ''); ?>"
                                href="<?php echo e(route('edit')); ?>">Edit
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container mt-5  ">
            <div class="head mb-5">
                <div class="row justify-content-end">
                    <div class="col-3">
                        <div class="search">
                            <form action="<?php echo e(route('search')); ?>" method="GET">
                                <div class="d-flex">
                                    <input type="text" class="form-control keyword" name="keyword" id="keyword"
                                        placeholder="Từ vựng">
                                    <button type="submit" class="btn btn-primary w-100">Tìm kiếm</button>
                                </div>

                            </form>
                        </div>
                        <div class="mt-5">
                            <p>Hiện tại có : <span class="text-danger"><?php echo e(count($vocabulary)); ?></span> từ vựng</p>

                        </div>
                    </div>
                    <?php if($fullUrl == $defaultUrl): ?>
                        <div class="col-9">
                            <div class="search">
                                
                                <div class="row justify-content-center">
                                    <div class="group-input mx-3 col-3">
                                        <input type="text" name="english"
                                            class="form-control w-100 mb-2  <?php $__errorArgs = ['english'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="english" placeholder="Tiếng anh" value="<?php echo e(old('english')); ?>">
                                        
                                        <span class="invalid-feedback" id="english-error"></span>
                                    </div>
                                    <div class="group-input  mx-3 col-3">
                                        <input type="text" name="vietnam"
                                            class="form-control w-100 mb-2  <?php $__errorArgs = ['vietnam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="vietnam" placeholder="Tiếng việt" value="<?php echo e(old('vietnam')); ?>">
                                        
                                        <span class="invalid-feedback" id="vietnam-error"></span>

                                    </div>
                                    <div class="group-input mx-3 col-3">
                                        <select id="type" name="type"
                                            class="form-control  <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="">Chọn loại từ</option>
                                            <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($item->name == 'N'): ?>
                                                    <option value="<?php echo e($item->id); ?>" class="mr-2"
                                                        style="color: #28a745;"><?php echo e($item->name); ?>

                                                        (<?php echo e($item->description); ?>)
                                                    </option>
                                                <?php elseif($item->name == 'V'): ?>
                                                    <option value="<?php echo e($item->id); ?>" class="mr-2"
                                                        style="color: #007bff;"><?php echo e($item->name); ?>

                                                        (<?php echo e($item->description); ?>)
                                                    </option>
                                                <?php elseif($item->name == 'Adj'): ?>
                                                    <option value="<?php echo e($item->id); ?>" class="mr-2"
                                                        style="color: #dc3545;"><?php echo e($item->name); ?>

                                                        (<?php echo e($item->description); ?>)
                                                    </option>
                                                <?php elseif($item->name == 'Adv'): ?>
                                                    <option value="<?php echo e($item->id); ?>" class="mr-2"
                                                        style="color: #fd7e14;"><?php echo e($item->name); ?>

                                                        (<?php echo e($item->description); ?>)
                                                    </option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($item->id); ?>" class="mr-2" style="">
                                                        <?php echo e($item->name); ?>

                                                        (<?php echo e($item->description); ?>)
                                                    </option>
                                                <?php endif; ?>
                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <span class="invalid-feedback" id="type-error"></span>

                                    </div>
                                    <button type="submit" class="btn btn-primary btn-add-vocabulary col-3 mt-3 w-100">Thêm
                                        từ
                                        vựng</button>
                                </div>
                                
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row" id="main_content">
                <?php
                    $t = 0;
                ?>
                <?php $__currentLoopData = $vocabulary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $t++;
                    ?>
                    <div class="col-xl-6 col-sm-6 vocabulary-item">
                        <ul class="list-unstyled">
                            <li class="d-flex align-items-center mb-2">
                                <p class="mr-2"><?php echo e($t); ?>/</p>
                                <?php if($item->type->name == 'N'): ?>
                                    <p class="vocabulary-vn mr-2" style="color: #28a745;"> <?php echo e($item->english); ?></p>
                                    <p style="color: #28a745;">(<?php echo e($item->type->name); ?>)</p>
                                <?php elseif($item->type->name == 'V'): ?>
                                    <p class="vocabulary-vn mr-2" style="color: #007bff;"><?php echo e($item->english); ?></p>
                                    <p style="color: #007bff;">(<?php echo e($item->type->name); ?>)</p>
                                <?php elseif($item->type->name == 'Adj'): ?>
                                    <p class="vocabulary-vn mr-2" style="color: #dc3545;"><?php echo e($item->english); ?></p>
                                    <p style="color: #dc3545;">(<?php echo e($item->type->name); ?>)</p>
                                <?php elseif($item->type->name == 'Adv'): ?>
                                    <p class="vocabulary-vn mr-2" style="color: #fd7e14;"><?php echo e($item->english); ?></p>
                                    <p style="color: #fd7e14;">(<?php echo e($item->type->name); ?>)</p>
                                <?php else: ?>
                                    <p class="vocabulary-vn mr-2" style=""><?php echo e($item->english); ?></p>
                                    <p style="">(<?php echo e($item->type->name); ?>)</p>
                                <?php endif; ?>
                                
                                <p class="mx-3">:</p>
                                <p class="vocabulary-vn" style="color: #6c757d;"><?php echo e($item->vietnam); ?></p>
                                
                                <div class="d-flex list_action">
                                    <button style="border:none" data-toggle="modal" data-target="#myModalEdit"
                                        data-eng="<?php echo e($item->english); ?>" data-vn="<?php echo e($item->vietnam); ?>"
                                        data-type="<?php echo e($item->type->id); ?>" data-id="<?php echo e($item->id); ?>">
                                        <img src="<?php echo e(asset('public/img/edit.png')); ?>" alt="edit vocabulary"
                                            class="action-icon">
                                    </button>

                                    <button class="delete-link btn-delete-vocabulary " data-id="<?php echo e($item->id); ?>">
                                        <img src="<?php echo e(asset('public/img/delete.png')); ?>" alt=""
                                            class="action-icon">
                                    </button>

                                </div>
                            </li>
                        </ul>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <?php echo $__env->make('modal.modal_edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script>
            $('.btn-add-vocabulary').click(function(e) {
                e.preventDefault(); // Ngăn form submit
                $('.content').addClass("loading");
                $(".form-control").removeClass("is-invalid"); // Xóa class lỗi
                $(".invalid-feedback").text(""); // Xóa thông báo lỗi cũ
                // const year = $("#select_year").val();
                const english = $("#english").val();
                const vietnam = $("#vietnam").val();
                const type = $("#type").val();
                data = {
                    english: english,
                    vietnam: vietnam,
                    type: type,
                }
                console.log("Dữ liệu gửi:", data); // Kiểm tra dữ liệu trước khi gửi
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: "<?php echo e(route('add')); ?>",
                    type: "POST",
                    data: data,
                    success: function(response) {
                        $('.content').html(response);
                        setTimeout(function() {
                            $(".content").removeClass("loading");
                            Swal.fire({
                                title: "Thành công!",
                                text: "Thêm từ vựng thành công!",
                                icon: "success",
                                confirmButtonText: "OK"
                            });
                        }, 1500);

                    },

                    error: function(xhr) {
                        // $(".content").removeClass("loading");
                        setTimeout(function() {
                            $(".content").removeClass("loading");
                            if (xhr.status === 422) {
                                let errors = xhr.responseJSON.errors;

                                // Duyệt qua từng lỗi và hiển thị dưới input
                                Object.keys(errors).forEach(function(key) {
                                    $("#" + key).addClass(
                                        "is-invalid"); // Thêm class đỏ vào input
                                    $("#" + key + "-error").text(errors[key][
                                        0
                                    ]); // Hiển thị lỗi
                                });
                            } else {
                                Swal.fire("Lỗi!", "Có lỗi xảy ra. Vui lòng thử lại!", "error");
                            }
                        }, 800);

                    },
                    complete: function() {
                        // $(".content").removeClass("loading");
                    },

                })

            })
        </script>
        <script>
            $(document).on('click', '.btn-delete-vocabulary', function() {
                let vocabularyId = $(this).data('id');
                let row = $(this).closest('.vocabulary-item');
                var url = '<?php echo e($defaultUrl); ?>' + "/delete/" + vocabularyId;
                Swal.fire({
                    title: "Xác nhận xóa?",
                    text: "Bạn có chắc chắn muốn xóa từ vựng này không?",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#d33",
                    cancelButtonColor: "#3085d6",
                    confirmButtonText: "Xóa",
                    cancelButtonText: "Hủy"
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            },
                            type: "GET",
                            url: url,
                            data: {
                                id: vocabularyId
                            },
                            success: function(response) {
                                Swal.fire({
                                    title: "Đã xóa!",
                                    text: response.message,
                                    icon: "success",
                                    timer: 1000, // Hiển thị 1s trước khi reload
                                    showConfirmButton: false
                                }).then(() => {
                                    setTimeout(() => {
                                        window.location.href =
                                            "/project_vocabulary_IELTS/"; // Reload sau 1 giây
                                    }, 200);
                                });
                            },
                            error: function(xhr) {
                                Swal.fire("Lỗi!", "Không thể xóa từ vựng.", xhr.vocabulary);
                            }
                        });
                    }
                });
            });
            $(document).ready(function() {
                var timeout = null;
                var url = '<?php echo e($defaultUrl); ?>' + "/search/searchajax/";
                var assetUrl = '<?php echo e($defaultUrl); ?>';

                var getColor = function(type_id) {
                    var colors = {
                        '1': '#fd7e14', // adv - màu cam
                        '2': '#dc3545', // adj - màu đỏ
                        '3': '#007bff', // v - màu xanh dương
                        '4': '#28a745', // n - màu xanh lá
                        '5': '#6c757d' // cụm từ - màu xám
                    };
                    return colors[type_id] || '#6c757d';
                };

                var getTypeName = function(type_id) {
                    var types = {
                        '1': 'Adv',
                        '2': 'Adj',
                        '3': 'V',
                        '4': 'N',
                        '5': 'Cụm từ'
                    };
                    return types[type_id] || 'Cụm từ';
                };

                var createVocabularyItem = function(index, value) {
                    var color = getColor(value.type_id);
                    var typeName = getTypeName(value.type_id);
                    return `
                <div class="col-xl-6 col-sm-6">
                    <ul class="list-unstyled">
                        <li class="d-flex align-items-center mb-2">
                            <p class="mr-2">${index + 1}/</p>
                            <p class="mr-2" style="color: ${color};">${value.english}</p>
                            <p style="color: ${color};">(${typeName})</p>
                            <p class="mx-3">:</p>
                            <p style="color: #6c757d;">${value.vietnam}</p>
                             <div class="d-flex list_action">
                    <button style="border:none" data-toggle="modal" data-target="#myModalEdit"
                        data-eng="${value.english}" data-vn="${value.vietnam}"
                        data-type="${value.type_id}" data-id="${value.id}">
                        <img src="${assetUrl}/public/img/edit.png" alt="edit vocabulary"
                            class="action-icon">
                    </button>
                       <button class="delete-link btn-delete-vocabulary " data-id="${value.id}">
                                        <img src="<?php echo e(asset('public/img/delete.png')); ?>" alt=""
                                            class="action-icon">
                                    </button>
                </div>
                        </li>
                    </ul>
                </div>
            `;
                };
                $('.keyword').keyup(function() {
                    clearTimeout(timeout);
                    timeout = setTimeout(function() {
                        var data = {
                            keyword: $('.keyword').val(),
                        };
                        // console.log(data);

                        $.ajax({
                            type: 'get',
                            dataType: 'json',
                            data: data,
                            url: url,
                            success: function(data) {
                                $('#main_content').empty();
                                // console.log(data.vocabulary);

                                if (data.vocabulary.length > 0) {
                                    var content = data.vocabulary.map(function(value,
                                        index) {
                                        return createVocabularyItem(index, value);
                                    }).join('');
                                    $('#main_content').html(content);
                                } else {
                                    $('#main_content').html(`
                            <div class="col-12">
                                <div class="alert alert-warning" role="alert">
                                    Không có từ vựng
                                </div>
                            </div>
                        `);
                                }
                            },
                            error: function(xhr, ajaxOptions, thrownError) {
                                console.error('Lỗi AJAX:', xhr.status, thrownError);
                            },
                        });
                    }, 200);
                });
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\project_vocabulary_IELTS\resources\views/index.blade.php ENDPATH**/ ?>